import React from 'react';
import Democrat from './Democrats';
import MyButton from './Button';
import  './client'; 
import './App.css';


function App() {

  return (
    <div className="App">
      <Democrat/>
      <MyButton/>
    </div>
  );
}

export default App;

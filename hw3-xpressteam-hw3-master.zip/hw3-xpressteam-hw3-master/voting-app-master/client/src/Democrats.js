import React, { Component } from "react";
import kamala from './assets/kamala.jpg';
import bernie from './assets/bernie.jpg';
import joe from './assets/joe.jpg';

export default class Democrat extends Component {

  constructor() {
    super();
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(event) {
    event.preventDefault();
    const data = new FormData(event.target);
    
    fetch('/api/form-submit-url', {
      method: 'POST',
      body: data,
    });
  }

render(){
  return (

<table style={{ width: "100%" }}>
      <tr>
        <th></th>
        <th> <h1>Democratic Party</h1></th>
        <th></th>
      </tr>
      <tr>
        <th> <img src={bernie} width="200px" height="250px" alt="Bernie Sanders" /> </th>
        <th> <img src={kamala} width="200px" height="250px" alt="Kamala Harris" /></th>
        <th> <img src={joe} width="200px" height="250px" alt="Joe Biden" /> </th>
      </tr>
</table>




  )
};}

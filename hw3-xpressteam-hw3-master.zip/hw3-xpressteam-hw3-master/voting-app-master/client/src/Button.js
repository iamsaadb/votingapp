import React, { Component } from "react";
import ReactDOM from "react-dom";

export default class MyButton extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            value1: 0,
            value2: 0,
            value3: 0
        };
        this.bernieButton = this.bernieButton.bind(this);
        this.kamalaButton = this.kamalaButton.bind(this);
        this.joeButton = this.joeButton.bind(this);

    }

    bernieButton(event) {
        this.setState({ value1: this.state.value1 + 1 });
        console.log("Bernie button clicked" + event.target.id + " and it has " + (this.state.value1 + 1) + " votes");
    }
    kamalaButton(event) {
        this.setState({ value2: this.state.value2 + 1 });
        console.log("Kamala button clicked" + event.target.id + " and it has " +  (this.state.value2 + 1) + " votes");
    }
    joeButton(event) {
        this.setState({ value3: this.state.value3 + 1 });
        console.log("Joe button clicked" + event.target.id + " and it has " +  (this.state.value3 + 1) + " votes" );
    }




    render() {
        return (
            <div>
                <table style={{ width: "100%" }}>
                    <tr>
                        <th>
                            <div id="counter1">{this.state.value1}</div>
                            <button id="myButton1" formAction="/bernie" onClick={(this.bernieButton)}>Click</button>
                        </th>
                        <th>
                            <div id="counter2">{this.state.value2}</div>
                            <button id="myButton2" formAction="/kamala" onClick={(this.kamalaButton)}>Click</button>
                        </th>
                        <th>
                            <div id="counter3">{this.state.value3}</div>
                            <button id="myButton3" formAction="/joe" onClick={(this.joeButton)}>Click</button>
                        </th>
                    </tr>
                </table>
                <script src="client.js"></script>

                {/* <div>{this.state.value}</div>
                <button onClick={this.buttonClicked}>Click</button> */}
            </div>

        );
    }
}

ReactDOM.render(
    <MyButton />,
    document.getElementById('root')
);